using System;

namespace UnityEditor.TestTools.TestRunner.CommandLineTest
{
    [Serializable]
    internal class ExecutionSettings
    {
        public string TestResultsFile;
        public string DeviceLogsDirectory;
    }
}
